service Multiplexing_Calculator {
    i32 add(1: i32 x, 2: i32 y)
}

service Multiplexing_WeatherReport {
    double getTemperature()
}
