## C# Coding Standards

Please follow:
 * [Thrift General Coding Standards](/doc/coding_standards.md)
 * [MSDN C# Coding Conventions](http://msdn.microsoft.com/en-us/library/ff926074.aspx)
 * [C# Coding Guidelines](http://csharpguidelines.codeplex.com/)
