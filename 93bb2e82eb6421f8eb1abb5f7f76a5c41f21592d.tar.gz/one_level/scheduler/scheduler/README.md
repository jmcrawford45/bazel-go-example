# Scoot Scheduler

The Scoot Scheduler is responsible for receiving job requests from the Cloud
API, and distributing the jobs to workers and maintaining and communicating
the state of jobs run.
