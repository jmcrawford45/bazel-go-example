/*
Package thrift implements the Scoot API, see scoot.thrift for details
*/
package thrift
