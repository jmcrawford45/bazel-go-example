/*
Package api implements the Scoot thrift API and the TwitterServer http API.
*/
package api
