package scheduler

const DefaultSched_Thrift string = "localhost:9090"
const DefaultSched_HTTP string = "localhost:9091"
