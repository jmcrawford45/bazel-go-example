# Domain

The Scoot Scheduler's domain subdirectory provides:
* __domain__ - scheduler go objects: jobs, tasks and states, and thrift versions of these objects
  * __gen-go/sched__ - generated code from the thrift definitions
