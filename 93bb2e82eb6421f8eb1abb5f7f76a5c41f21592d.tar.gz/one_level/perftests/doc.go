/*
perftests contains tooling for running platform performance tests.
*/
package perftests
