package tags

type LogTags struct {
	Tag    string
	JobID  string
	TaskID string
}
