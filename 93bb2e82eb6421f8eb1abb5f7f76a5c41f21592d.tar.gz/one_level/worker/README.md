# Scoot Worker

This contains the Worker API Thrift definition, generated code, and worker
server and client implementations.
