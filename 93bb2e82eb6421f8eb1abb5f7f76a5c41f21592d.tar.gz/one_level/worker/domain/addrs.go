package domain

const DefaultWorker_Thrift string = "localhost:9092"
const DefaultWorker_HTTP string = "localhost:9093"

const WorkerPorts = 10100
