package os

const (
	bytesToKB = 1024

	AbortTimeoutSec = 10
)
