### Binaries

A location for site-specific binaries that inject dependencies.

* __scoot-snapshot-db__ - CLI client for snapshot store (via apiserver)
